export default class AutofillForm {
	opid: string;
	htmlName: string;
	htmlID: string;
	htmlAction: string;
	htmlMethod: string;
}
